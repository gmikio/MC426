package exercise2;

public class Employee {

	private int rate;

	public Employee(int rate) {
		this.rate = rate;
	}

	public int getRate() {
		return rate;
	}
}
