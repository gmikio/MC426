package exercise4;

public class Course {
	public Course(String name, boolean isAdvanced) {
		// ...
	}

	public boolean isAdvanced() {
		// ...
		return false;
	}
}
