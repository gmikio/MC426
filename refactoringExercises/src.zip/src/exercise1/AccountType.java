package exercise1;

public class AccountType {

    // Class totally deleted since it's unnecessary
    // This Class should be an attribute of the Class "Account", with the method "isPremmium" being
    // a method of the class "Account"
	

}
